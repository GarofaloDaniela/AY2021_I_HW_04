/*******************************************************************************
* File Name: Photoresistor_pin.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Photoresistor_pin_H) /* Pins Photoresistor_pin_H */
#define CY_PINS_Photoresistor_pin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Photoresistor_pin_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Photoresistor_pin__PORT == 15 && ((Photoresistor_pin__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Photoresistor_pin_Write(uint8 value);
void    Photoresistor_pin_SetDriveMode(uint8 mode);
uint8   Photoresistor_pin_ReadDataReg(void);
uint8   Photoresistor_pin_Read(void);
void    Photoresistor_pin_SetInterruptMode(uint16 position, uint16 mode);
uint8   Photoresistor_pin_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Photoresistor_pin_SetDriveMode() function.
     *  @{
     */
        #define Photoresistor_pin_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Photoresistor_pin_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Photoresistor_pin_DM_RES_UP          PIN_DM_RES_UP
        #define Photoresistor_pin_DM_RES_DWN         PIN_DM_RES_DWN
        #define Photoresistor_pin_DM_OD_LO           PIN_DM_OD_LO
        #define Photoresistor_pin_DM_OD_HI           PIN_DM_OD_HI
        #define Photoresistor_pin_DM_STRONG          PIN_DM_STRONG
        #define Photoresistor_pin_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Photoresistor_pin_MASK               Photoresistor_pin__MASK
#define Photoresistor_pin_SHIFT              Photoresistor_pin__SHIFT
#define Photoresistor_pin_WIDTH              1u

/* Interrupt constants */
#if defined(Photoresistor_pin__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Photoresistor_pin_SetInterruptMode() function.
     *  @{
     */
        #define Photoresistor_pin_INTR_NONE      (uint16)(0x0000u)
        #define Photoresistor_pin_INTR_RISING    (uint16)(0x0001u)
        #define Photoresistor_pin_INTR_FALLING   (uint16)(0x0002u)
        #define Photoresistor_pin_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Photoresistor_pin_INTR_MASK      (0x01u) 
#endif /* (Photoresistor_pin__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Photoresistor_pin_PS                     (* (reg8 *) Photoresistor_pin__PS)
/* Data Register */
#define Photoresistor_pin_DR                     (* (reg8 *) Photoresistor_pin__DR)
/* Port Number */
#define Photoresistor_pin_PRT_NUM                (* (reg8 *) Photoresistor_pin__PRT) 
/* Connect to Analog Globals */                                                  
#define Photoresistor_pin_AG                     (* (reg8 *) Photoresistor_pin__AG)                       
/* Analog MUX bux enable */
#define Photoresistor_pin_AMUX                   (* (reg8 *) Photoresistor_pin__AMUX) 
/* Bidirectional Enable */                                                        
#define Photoresistor_pin_BIE                    (* (reg8 *) Photoresistor_pin__BIE)
/* Bit-mask for Aliased Register Access */
#define Photoresistor_pin_BIT_MASK               (* (reg8 *) Photoresistor_pin__BIT_MASK)
/* Bypass Enable */
#define Photoresistor_pin_BYP                    (* (reg8 *) Photoresistor_pin__BYP)
/* Port wide control signals */                                                   
#define Photoresistor_pin_CTL                    (* (reg8 *) Photoresistor_pin__CTL)
/* Drive Modes */
#define Photoresistor_pin_DM0                    (* (reg8 *) Photoresistor_pin__DM0) 
#define Photoresistor_pin_DM1                    (* (reg8 *) Photoresistor_pin__DM1)
#define Photoresistor_pin_DM2                    (* (reg8 *) Photoresistor_pin__DM2) 
/* Input Buffer Disable Override */
#define Photoresistor_pin_INP_DIS                (* (reg8 *) Photoresistor_pin__INP_DIS)
/* LCD Common or Segment Drive */
#define Photoresistor_pin_LCD_COM_SEG            (* (reg8 *) Photoresistor_pin__LCD_COM_SEG)
/* Enable Segment LCD */
#define Photoresistor_pin_LCD_EN                 (* (reg8 *) Photoresistor_pin__LCD_EN)
/* Slew Rate Control */
#define Photoresistor_pin_SLW                    (* (reg8 *) Photoresistor_pin__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Photoresistor_pin_PRTDSI__CAPS_SEL       (* (reg8 *) Photoresistor_pin__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Photoresistor_pin_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Photoresistor_pin__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Photoresistor_pin_PRTDSI__OE_SEL0        (* (reg8 *) Photoresistor_pin__PRTDSI__OE_SEL0) 
#define Photoresistor_pin_PRTDSI__OE_SEL1        (* (reg8 *) Photoresistor_pin__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Photoresistor_pin_PRTDSI__OUT_SEL0       (* (reg8 *) Photoresistor_pin__PRTDSI__OUT_SEL0) 
#define Photoresistor_pin_PRTDSI__OUT_SEL1       (* (reg8 *) Photoresistor_pin__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Photoresistor_pin_PRTDSI__SYNC_OUT       (* (reg8 *) Photoresistor_pin__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Photoresistor_pin__SIO_CFG)
    #define Photoresistor_pin_SIO_HYST_EN        (* (reg8 *) Photoresistor_pin__SIO_HYST_EN)
    #define Photoresistor_pin_SIO_REG_HIFREQ     (* (reg8 *) Photoresistor_pin__SIO_REG_HIFREQ)
    #define Photoresistor_pin_SIO_CFG            (* (reg8 *) Photoresistor_pin__SIO_CFG)
    #define Photoresistor_pin_SIO_DIFF           (* (reg8 *) Photoresistor_pin__SIO_DIFF)
#endif /* (Photoresistor_pin__SIO_CFG) */

/* Interrupt Registers */
#if defined(Photoresistor_pin__INTSTAT)
    #define Photoresistor_pin_INTSTAT            (* (reg8 *) Photoresistor_pin__INTSTAT)
    #define Photoresistor_pin_SNAP               (* (reg8 *) Photoresistor_pin__SNAP)
    
	#define Photoresistor_pin_0_INTTYPE_REG 		(* (reg8 *) Photoresistor_pin__0__INTTYPE)
#endif /* (Photoresistor_pin__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Photoresistor_pin_H */


/* [] END OF FILE */
