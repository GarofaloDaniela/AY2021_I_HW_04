/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/*
    File UART_CustomFunctions.c
    Functions aimed to ensure the proper operation of the UART component with respect to the requirements
    Author: Daniela Garofalo
*/
    
#include <UART_CustomFunctions.h>

/* [] END OF FILE */
